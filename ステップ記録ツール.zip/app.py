import os
import sys
import json
import shutil
import webbrowser
import threading
from http.server import SimpleHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs
from datetime import datetime
from PIL import Image, ImageFilter, ImageDraw
import win32gui
from win32com.shell import shell, shellcon
import pythoncom
from listener import StepsListener

# Set up paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
WEB_DIR = os.path.join(BASE_DIR, "web")
TEMP_DIR = os.path.join(BASE_DIR, "temp_images")
DEFAULT_EXPORT_DIR = os.path.join(BASE_DIR, "exports")

def select_folder_win32():
    pythoncom.CoInitialize()
    try:
        # Get active window to act as parent for the modal dialog
        hwnd_active = win32gui.GetForegroundWindow()
        # BIF_RETURNONLYFSDIRS = 0x0001, BIF_NEWDIALOGSTYLE = 0x0040
        pidl, display_name, image_list = shell.SHBrowseForFolder(
            hwnd_active,
            None,
            "出力先フォルダを選択してください",
            0x0001 | 0x0040,
            None,
            None
        )
        if pidl:
            path = shell.SHGetPathFromIDList(pidl)
            if isinstance(path, bytes):
                return path.decode('utf-8', errors='ignore')
            return path
    except Exception as e:
        print(f"Error in select_folder_win32: {e}")
        raise e
    finally:
        pythoncom.CoUninitialize()
    return None


# Initialize global variables
listener = None
httpd = None

class StepsHTTPHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        # Disable caching for temp images to ensure updates are visible immediately
        if "temp_images" in self.path:
            self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
            self.send_header('Pragma', 'no-cache')
            self.send_header('Expires', '0')
        super().end_headers()

    def do_GET(self):
        url_parts = urlparse(self.path)
        path = url_parts.path

        # API Endpoints
        if path == "/api/status":
            self.send_json({
                "is_recording": listener.is_recording if listener else False,
                "step_count": len(listener.steps) if listener else 0
            })
            return

        elif path == "/api/steps":
            steps_data = listener.steps if listener else []
            has_deleted = len(listener.deleted_steps) > 0 if (listener and hasattr(listener, 'deleted_steps')) else False
            self.send_json({
                "steps": steps_data,
                "has_deleted_steps": has_deleted
            })
            return

        # Serve static files from temp_images
        elif path.startswith("/temp_images/"):
            file_name = path.replace("/temp_images/", "")
            file_path = os.path.join(TEMP_DIR, file_name)
            if os.path.exists(file_path):
                self.serve_file(file_path, "image/png")
            else:
                self.send_error(404, "File not found")
            return

        # Serve static files from web/
        else:
            if path == "/" or path == "":
                path = "/index.html"
            
            file_path = os.path.join(WEB_DIR, path.lstrip("/"))
            if os.path.exists(file_path):
                ext = os.path.splitext(file_path)[1]
                mime_types = {
                    ".html": "text/html",
                    ".css": "text/css",
                    ".js": "application/javascript",
                    ".png": "image/png",
                    ".jpg": "image/jpeg",
                    ".ico": "image/x-icon"
                }
                mime = mime_types.get(ext, "application/octet-stream")
                self.serve_file(file_path, mime)
            else:
                self.send_error(404, "File not found")
            return

    def do_POST(self):
        url_parts = urlparse(self.path)
        path = url_parts.path

        # Read JSON body
        content_length = int(self.headers.get('Content-Length', 0))
        post_data = self.rfile.read(content_length) if content_length > 0 else b""
        
        try:
            body = json.loads(post_data) if post_data else {}
        except Exception:
            body = {}

        if path == "/api/start":
            if listener:
                disable_uia = body.get("disable_uia", False)
                enable_keyboard = body.get("enable_keyboard_hook", False)
                listener.disable_uia = disable_uia
                listener.enable_keyboard_hook = enable_keyboard
                listener.start()
                self.send_json({"status": "success", "message": "Recording started"})
            else:
                self.send_json({"status": "error", "message": "Listener not initialized"}, 500)

        elif path == "/api/stop":
            if listener:
                listener.stop()
                self.send_json({"status": "success", "message": "Recording stopped"})
            else:
                self.send_json({"status": "error", "message": "Listener not initialized"}, 500)

        elif path == "/api/clear":
            if listener:
                listener.clear()
                self.send_json({"status": "success", "message": "Steps cleared"})
            else:
                self.send_json({"status": "error", "message": "Listener not initialized"}, 500)

        elif path == "/api/steps/edit":
            step_id = body.get("id")
            new_desc = body.get("action_desc")
            
            if not step_id or new_desc is None:
                self.send_json({"status": "error", "message": "Missing arguments"}, 400)
                return

            updated = False
            for step in listener.steps:
                if step["id"] == step_id:
                    step["action_desc"] = new_desc
                    updated = True
                    break

            if updated:
                self.send_json({"status": "success"})
            else:
                self.send_json({"status": "error", "message": "Step not found"}, 404)

        elif path == "/api/steps/delete":
            step_id = body.get("id")
            if not step_id:
                self.send_json({"status": "error", "message": "Missing arguments"}, 400)
                return

            deleted = False
            for i, step in enumerate(listener.steps):
                if step["id"] == step_id:
                    # Archive in garbage bin rather than physically deleting
                    if not hasattr(listener, 'deleted_steps'):
                        listener.deleted_steps = []
                    listener.deleted_steps.append(step)
                    listener.steps.pop(i)
                    deleted = True
                    break

            if deleted:
                # Re-index steps to maintain continuous numbering
                for idx, step in enumerate(listener.steps):
                    step["id"] = idx + 1
                listener.step_counter = len(listener.steps)
                self.send_json({"status": "success"})
            else:
                self.send_json({"status": "error", "message": "Step not found"}, 404)

        elif path == "/api/steps/undo_delete":
            if listener and hasattr(listener, 'deleted_steps') and len(listener.deleted_steps) > 0:
                # Pop last deleted step from the trash stack
                restored_step = listener.deleted_steps.pop()
                listener.steps.append(restored_step)
                
                # Sort steps chronologically by timestamp to preserve original operation order
                listener.steps.sort(key=lambda s: s.get("timestamp", ""))
                
                # Re-index steps to maintain continuous numbering
                for idx, step in enumerate(listener.steps):
                    step["id"] = idx + 1
                listener.step_counter = len(listener.steps)
                self.send_json({"status": "success"})
            else:
                self.send_json({"status": "error", "message": "No steps to restore"}, 400)

        elif path == "/api/steps/blur":
            step_id = body.get("id")
            # Bounding box on the screenshot: [x1, y1, x2, y2]
            rect = body.get("rect") 

            if not step_id or not rect or len(rect) != 4:
                self.send_json({"status": "error", "message": "Invalid arguments"}, 400)
                return

            img_name = None
            for step in listener.steps:
                if step["id"] == step_id:
                    img_name = step["image_name"]
                    break

            if not img_name:
                self.send_json({"status": "error", "message": "Step not found"}, 404)
                return

            img_path = os.path.join(TEMP_DIR, img_name)
            if os.path.exists(img_path):
                try:
                    img = Image.open(img_path)
                    # Coordinates from client: x1, y1, x2, y2
                    x1, y1, x2, y2 = int(rect[0]), int(rect[1]), int(rect[2]), int(rect[3])
                    
                    # Ensure coordinates are sorted and within image boundaries
                    w, h = img.size
                    x1, x2 = sorted([max(0, min(x1, w)), max(0, min(x2, w))])
                    y1, y2 = sorted([max(0, min(y1, h)), max(0, min(y2, h))])

                    if x2 > x1 and y2 > y1:
                        box = (x1, y1, x2, y2)
                        cropped = img.crop(box)
                        blurred = cropped.filter(ImageFilter.GaussianBlur(radius=15))
                        img.paste(blurred, box)
                        
                        # Draw visual outline for manual blur as well
                        draw = ImageDraw.Draw(img)
                        draw.rectangle(box, outline="red", width=2)
                        
                        img.save(img_path)

                        # Set is_blurred flag to True
                        for s in listener.steps:
                            if s["id"] == step_id:
                                s["is_blurred"] = True
                                break

                        self.send_json({"status": "success"})
                    else:
                        self.send_json({"status": "error", "message": "Zero-area selection"}, 400)
                except Exception as e:
                    self.send_json({"status": "error", "message": str(e)}, 500)
            else:
                self.send_json({"status": "error", "message": "Image not found on disk"}, 404)

        elif path == "/api/steps/reset_blur":
            step_id = body.get("id")
            if not step_id:
                self.send_json({"status": "error", "message": "Missing arguments"}, 400)
                return

            updated = False
            for step in listener.steps:
                if step["id"] == step_id:
                    orig_name = step.get("original_image_name")
                    img_name = step["image_name"]
                    
                    if orig_name:
                        orig_path = os.path.join(TEMP_DIR, orig_name)
                        img_path = os.path.join(TEMP_DIR, img_name)
                        
                        if os.path.exists(orig_path):
                            try:
                                shutil.copy2(orig_path, img_path)
                                step["is_blurred"] = False
                                step["auto_blurred"] = False
                                updated = True
                            except Exception as e:
                                self.send_json({"status": "error", "message": f"Reset failed: {e}"}, 500)
                                return
                    break

            if updated:
                self.send_json({"status": "success"})
            else:
                self.send_json({"status": "error", "message": "Step not found or no original image"}, 404)

        elif path == "/api/select_folder":
            try:
                folder_selected = select_folder_win32()
                if folder_selected:
                    folder_selected = os.path.normpath(folder_selected)
                    self.send_json({"status": "success", "folder": folder_selected})
                else:
                    self.send_json({"status": "cancelled"})
            except Exception as e:
                self.send_json({"status": "error", "message": str(e)}, 500)

        elif path == "/api/export":
            custom_dir = body.get("export_dir", "").strip()
            author = body.get("author", "").strip() or "未指定"
            version = body.get("version", "").strip() or "1.0.0"
            system_specs = body.get("system_specs", "").strip()
            
            if custom_dir:
                export_path = custom_dir
            else:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                export_path = os.path.join(DEFAULT_EXPORT_DIR, f"manual_{timestamp}")

            try:
                # Create export folders
                image_export_dir = os.path.join(export_path, "images")
                os.makedirs(image_export_dir, exist_ok=True)

                current_date = datetime.now().strftime('%Y-%m-%d')
                current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

                # ----------------------------------------------------
                # 1. Generate Markdown content
                # ----------------------------------------------------
                md_lines = []
                md_lines.append("# 操作手順書")
                md_lines.append(f"\n* **作成者**: {author}")
                md_lines.append(f"* **バージョン**: {version}")
                md_lines.append(f"* **作成日時**: {current_time}")
                md_lines.append("\n---\n")

                # Version History Table in MD
                md_lines.append("## ■ 改訂履歴")
                md_lines.append("| バージョン | 改訂日 | 改訂内容 | 作成者 |")
                md_lines.append("| :--- | :--- | :--- | :--- |")
                md_lines.append(f"| {version} | {current_date} | 新規作成 | {author} |")
                md_lines.append("\n---\n")

                # System Specs in MD
                if system_specs:
                    md_lines.append("## ■ システム仕様・概要")
                    md_lines.append(system_specs)
                    md_lines.append("\n---\n")

                md_lines.append("## ■ 操作手順一覧\n")
                for step in listener.steps:
                    old_img_path = os.path.join(TEMP_DIR, step["image_name"])
                    new_img_name = f"step_{step['id']}.png"
                    new_img_path = os.path.join(image_export_dir, new_img_name)
                    
                    if os.path.exists(old_img_path):
                        shutil.copy2(old_img_path, new_img_path)

                    md_lines.append(f"### 手順 {step['id']}. {step['window_title']}")
                    md_lines.append(f"* **操作内容**: {step['action_desc']}")
                    md_lines.append(f"* **記録時間**: {step['timestamp']}")
                    md_lines.append(f"\n![手順 {step['id']}](images/{new_img_name})")
                    md_lines.append("\n---\n")

                # Write Markdown file
                md_file_path = os.path.join(export_path, "index.md")
                with open(md_file_path, "w", encoding="utf-8") as f:
                    f.write("\n".join(md_lines))

                # ----------------------------------------------------
                # 2. Generate HTML content (Beautiful Manual layout)
                # ----------------------------------------------------
                html_steps = []
                for step in listener.steps:
                    new_img_name = f"step_{step['id']}.png"
                    html_steps.append(f"""
                    <div class="step-card">
                        <div class="step-header">
                            <span class="step-number">手順 {step['id']}</span>
                            <span class="step-window">{step['window_title']}</span>
                            <span class="step-time">{step['timestamp']}</span>
                        </div>
                        <div class="step-body">
                            <div class="step-desc">{step['action_desc']}</div>
                            <div class="step-image-container">
                                <img src="images/{new_img_name}" alt="手順 {step['id']}" onclick="openZoomModal(this.src)" style="cursor: zoom-in;">
                            </div>
                        </div>
                    </div>
                    """)

                specs_html = f"""
                <div class="section-card">
                    <h2>■ システム仕様・概要</h2>
                    <p style="white-space: pre-wrap; line-height: 1.6; color: #334155;">{system_specs}</p>
                </div>
                """ if system_specs else ""

                html_content = f"""<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>操作手順書</title>
    <style>
        :root {{
            --bg-color: #f8fafc;
            --primary-color: #1e3a8a;
            --border-color: #e2e8f0;
            --text-dark: #1e293b;
            --text-light: #64748b;
        }}
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{
            background-color: var(--bg-color);
            color: var(--text-dark);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "游ゴシック体", YuGothic, "メイリオ", Meiryo, sans-serif;
            padding: 3rem 2rem;
            line-height: 1.5;
        }}
        .container {{
            max-width: 1000px;
            margin: 0 auto;
            background: #ffffff;
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 3rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        }}
        header {{
            border-bottom: 2px solid var(--primary-color);
            padding-bottom: 1.5rem;
            margin-bottom: 2rem;
        }}
        h1 {{
            color: var(--primary-color);
            font-size: 2.2rem;
            margin-bottom: 1rem;
        }}
        .meta-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            color: var(--text-light);
            font-size: 0.95rem;
        }}
        .meta-item strong {{ color: var(--text-dark); }}
        
        .section-card {{
            margin-bottom: 2.5rem;
        }}
        .section-card h2 {{
            color: var(--primary-color);
            font-size: 1.3rem;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 0.5rem;
            margin-bottom: 1rem;
        }}
        
        /* Table Styling */
        table {{
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 1.5rem;
            font-size: 0.95rem;
        }}
        th, td {{
            border: 1px solid var(--border-color);
            padding: 0.75rem 1rem;
            text-align: left;
        }}
        th {{
            background-color: #f1f5f9;
            color: var(--primary-color);
            font-weight: 700;
        }}
        
        /* Step Cards */
        .step-card {{
            border: 1px solid var(--border-color);
            border-radius: 8px;
            overflow: hidden;
            margin-bottom: 2.5rem;
            background: #ffffff;
        }}
        .step-header {{
            background: #f8fafc;
            border-bottom: 1px solid var(--border-color);
            padding: 0.75rem 1.25rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.9rem;
            color: var(--text-light);
        }}
        .step-number {{
            font-weight: 800;
            color: var(--primary-color);
            font-size: 1rem;
        }}
        .step-window {{
            font-weight: 600;
            color: var(--text-dark);
            flex: 1;
            margin: 0 1.5rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }}
        .step-body {{
            padding: 1.5rem;
        }}
        .step-desc {{
            font-size: 1.1rem;
            font-weight: 700;
            color: var(--text-dark);
            margin-bottom: 1rem;
            border-left: 4px solid var(--primary-color);
            padding-left: 0.75rem;
        }}
        .step-image-container {{
            border: 1px solid var(--border-color);
            border-radius: 6px;
            overflow: hidden;
            background-color: #000;
            display: flex;
            justify-content: center;
        }}
        .step-image-container img {{
            max-width: 100%;
            height: auto;
            display: block;
        }}
        
        /* Print Styles */
        @media print {{
            body {{ padding: 0; background: #fff; }}
            .container {{ border: none; box-shadow: none; padding: 0; }}
            .step-card {{ page-break-inside: avoid; }}
            .no-print {{ display: none !important; }}
        }}

        /* Image Zoom Modal Overlay */
        .zoom-modal {{
            display: none;
            position: fixed;
            z-index: 9999;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(10, 15, 30, 0.95);
            align-items: center;
            justify-content: center;
            flex-direction: column;
        }}
        .zoom-controls {{
            background: rgba(30, 41, 59, 0.85);
            border: 1px solid rgba(255, 255, 255, 0.1);
            padding: 0.6rem 1.2rem;
            border-radius: 9999px;
            display: flex;
            gap: 0.8rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
            z-index: 10000;
        }}
        .zoom-btn {{
            background: transparent;
            border: none;
            color: #f8fafc;
            font-size: 0.9rem;
            font-weight: 600;
            cursor: pointer;
            padding: 0.3rem 0.8rem;
            border-radius: 6px;
            transition: background 0.2s;
        }}
        .zoom-btn:hover {{
            background: rgba(255, 255, 255, 0.1);
        }}
        .zoom-btn.zoom-close {{
            color: #ef4444;
            border-left: 1px solid rgba(255, 255, 255, 0.15);
            padding-left: 1rem;
            margin-left: 0.2rem;
            border-radius: 0;
        }}
        .zoom-content-wrapper {{
            max-width: 90%;
            max-height: 80vh;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: auto;
            border-radius: 8px;
            background-color: #000;
        }}
        #zoom-expanded-img {{
            max-width: 100%;
            max-height: 75vh;
            object-fit: contain;
            transition: transform 0.15s ease-out;
            transform-origin: center center;
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>操作手順書</h1>
            <div class="meta-grid">
                <div class="meta-item"><strong>作成者:</strong> {author}</div>
                <div class="meta-item"><strong>バージョン:</strong> {version}</div>
                <div class="meta-item"><strong>作成日:</strong> {current_date}</div>
            </div>
        </header>

        <!-- 改訂履歴 -->
        <div class="section-card">
            <h2>■ 改訂履歴</h2>
            <table>
                <thead>
                    <tr>
                        <th>バージョン</th>
                        <th>改訂日</th>
                        <th>改訂内容</th>
                        <th>作成者</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>{version}</td>
                        <td>{current_date}</td>
                        <td>新規作成</td>
                        <td>{author}</td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- システム仕様・概要 -->
        {specs_html}

        <!-- 手順一覧 -->
        <div class="section-card">
            <h2>■ 操作手順一覧</h2>
            {"".join(html_steps)}
        </div>
    </div>

    <!-- Image Zoom Modal -->
    <div id="zoom-modal" class="zoom-modal no-print" onclick="closeZoomModal()">
        <div class="zoom-controls" onclick="event.stopPropagation()">
            <button class="zoom-btn" onclick="adjustZoom(0.2)">＋ 拡大</button>
            <button class="zoom-btn" onclick="adjustZoom(-0.2)">－ 縮小</button>
            <button class="zoom-btn" onclick="adjustZoom(0, true)">リセット</button>
            <button class="zoom-btn zoom-close" onclick="closeZoomModal()">✕ 閉じる</button>
        </div>
        <div class="zoom-content-wrapper" onclick="event.stopPropagation()">
            <img id="zoom-expanded-img" src="" alt="拡大画像">
        </div>
    </div>

    <script>
        let currentZoom = 1.0;
        const zoomModal = document.getElementById("zoom-modal");
        const zoomImg = document.getElementById("zoom-expanded-img");

        function openZoomModal(src) {{
            currentZoom = 1.0;
            zoomImg.src = src;
            zoomImg.style.transform = `scale(${{currentZoom}})`;
            zoomModal.style.display = "flex";
        }}

        function closeZoomModal() {{
            zoomModal.style.display = "none";
        }}

        function adjustZoom(amount, reset = false) {{
            if (reset) {{
                currentZoom = 1.0;
            }} else {{
                currentZoom = Math.max(0.2, Math.min(4.0, currentZoom + amount));
            }}
            zoomImg.style.transform = `scale(${{currentZoom}})`;
        }}
    </script>
</body>
</html>
"""
                html_file_path = os.path.join(export_path, "index.html")
                with open(html_file_path, "w", encoding="utf-8") as f:
                    f.write(html_content)

                # Open the export directory in Windows Explorer
                os.startfile(export_path)

                self.send_json({
                    "status": "success",
                    "export_dir": export_path,
                    "message": f"Successfully exported to {export_path}"
                })
            except Exception as e:
                self.send_json({"status": "error", "message": str(e)}, 500)

        elif path == "/api/shutdown":
            try:
                self.send_json({"status": "success", "message": "Server shutting down..."})
                
                # Shutdown the server in a separate thread to prevent deadlock
                def shutdown_worker():
                    time.sleep(0.5)
                    print("\nShutdown request received. Stopping server...")
                    if httpd:
                        httpd.shutdown()
                
                threading.Thread(target=shutdown_worker).start()
            except Exception as e:
                self.send_json({"status": "error", "message": str(e)}, 500)

        else:
            self.send_error(404, "Endpoint not found")

    def serve_file(self, file_path, mime_type):
        try:
            with open(file_path, "rb") as f:
                content = f.read()
            self.send_response(200)
            self.send_header("Content-Type", mime_type)
            self.send_header("Content-Length", str(len(content)))
            self.end_headers()
            self.wfile.write(content)
        except Exception as e:
            self.send_error(500, f"Internal server error: {e}")

    def send_json(self, data, status_code=200):
        try:
            content = json.dumps(data, ensure_ascii=False).encode("utf-8")
            self.send_response(status_code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(content)))
            self.end_headers()
            self.wfile.write(content)
        except Exception as e:
            self.send_error(500, f"Failed to encode JSON: {e}")

def run_server(port=8000):
    global listener, httpd
    listener = StepsListener(TEMP_DIR)
    
    server_address = ('127.0.0.1', port)
    httpd = HTTPServer(server_address, StepsHTTPHandler)
    
    print(f"Local server started at http://127.0.0.1:{port}")
    
    # Auto-open browser
    webbrowser.open(f"http://127.0.0.1:{port}")
    
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down server...")
    finally:
        print("Stopping listener and closing server...")
        if listener:
            listener.stop()
        if httpd:
            try:
                httpd.server_close()
            except Exception:
                pass
        print("Server stopped. Exiting process.")

if __name__ == "__main__":
    # Ensure temp directory is empty at startup
    if os.path.exists(TEMP_DIR):
        shutil.rmtree(TEMP_DIR)
    os.makedirs(TEMP_DIR, exist_ok=True)
    
    run_server()

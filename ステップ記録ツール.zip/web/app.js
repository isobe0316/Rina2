// State variables
let isRecording = false;
let steps = [];
let pollingInterval = null;
let toastTimeout = null;

// Modal Canvas State variables
let activeStepId = null;
let isDrawing = false;
let startX = 0;
let startY = 0;
let endX = 0;
let endY = 0;
const canvas = document.getElementById("blur-canvas");
const ctx = canvas.getContext("2d");
const modalImg = document.getElementById("modal-source-img");
const applyBlurBtn = document.getElementById("btn-modal-save");

// DOM Elements
const btnStart = document.getElementById("btn-start");
const btnStop = document.getElementById("btn-stop");
const btnClear = document.getElementById("btn-clear");
const btnUndo = document.getElementById("btn-undo");
const btnExport = document.getElementById("btn-export");
const exportDirInput = document.getElementById("export-dir");
const stepsList = document.getElementById("steps-list");
const stepCountBadge = document.getElementById("step-count-badge");
const statusText = document.getElementById("status-text");
const placeholder = document.getElementById("no-steps-placeholder");

// Initialize on Load
window.addEventListener("DOMContentLoaded", () => {
    checkStatus();
    loadSteps();
    setupEventListeners();
});

function setupEventListeners() {
    btnStart.addEventListener("click", startRecording);
    btnStop.addEventListener("click", stopRecording);
    btnClear.addEventListener("click", clearSteps);
    btnUndo.addEventListener("click", undoDeleteStep);
    btnExport.addEventListener("click", exportMarkdown);
    document.getElementById("btn-shutdown").addEventListener("click", shutdownServer);
    document.getElementById("btn-select-dir").addEventListener("click", selectFolderDialog);
    document.getElementById("btn-help").addEventListener("click", openHelpModal);

    // Modal close handlers
    document.getElementById("modal-close").addEventListener("click", closeModal);
    document.getElementById("btn-modal-cancel").addEventListener("click", closeModal);
    document.getElementById("help-modal-close").addEventListener("click", closeHelpModal);
    document.getElementById("btn-help-close").addEventListener("click", closeHelpModal);
    applyBlurBtn.addEventListener("click", applyManualBlur);

    // Canvas drawing mouse events
    canvas.addEventListener("mousedown", startDrawing);
    canvas.addEventListener("mousemove", drawSelection);
    canvas.addEventListener("mouseup", stopDrawing);
    canvas.addEventListener("mouseleave", stopDrawing);
}

// Show Toast Notifications
function showToast(message, type = "info") {
    const toast = document.getElementById("toast");
    toast.textContent = message;
    toast.className = `toast show ${type}`;
    
    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => {
        toast.className = "toast";
    }, 3000);
}

// Check Backend Status
async function checkStatus() {
    try {
        const response = await fetch("/api/status");
        const data = await response.json();
        
        isRecording = data.is_recording;
        updateUIState();

        if (isRecording) {
            startPolling();
        }
    } catch (e) {
        showToast("サーバーとの通信に失敗しました", "danger");
    }
}

// Toggle UI Elements based on recording status
function updateUIState() {
    const toggleUia = document.getElementById("toggle-uia");
    const toggleKeyboard = document.getElementById("toggle-keyboard-hook");
    if (isRecording) {
        btnStart.disabled = true;
        btnStop.disabled = false;
        if (toggleUia) toggleUia.disabled = true;
        if (toggleKeyboard) toggleKeyboard.disabled = true;
        statusText.textContent = "記録中";
        statusText.className = "status-indicator recording";
    } else {
        btnStart.disabled = false;
        btnStop.disabled = true;
        if (toggleUia) toggleUia.disabled = false;
        if (toggleKeyboard) toggleKeyboard.disabled = false;
        statusText.textContent = "待機中";
        statusText.className = "status-indicator offline";
    }
}

// Poll steps while recording
function startPolling() {
    if (pollingInterval) clearInterval(pollingInterval);
    pollingInterval = setInterval(loadSteps, 1000);
}

function stopPolling() {
    if (pollingInterval) {
        clearInterval(pollingInterval);
        pollingInterval = null;
    }
}

// API Call: Start Recording
async function startRecording() {
    const disableUia = document.getElementById("toggle-uia")?.checked || false;
    const enableKeyboardHook = document.getElementById("toggle-keyboard-hook")?.checked || false;
    try {
        const response = await fetch("/api/start", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ 
                disable_uia: disableUia,
                enable_keyboard_hook: enableKeyboardHook
            })
        });
        const data = await response.json();
        if (data.status === "success") {
            isRecording = true;
            updateUIState();
            startPolling();
            showToast("記録を開始しました。操作を行ってください。", "success");
        } else {
            showToast(data.message, "danger");
        }
    } catch (e) {
        showToast("エラーが発生しました", "danger");
    }
}

// API Call: Stop Recording
async function stopRecording() {
    try {
        const response = await fetch("/api/stop", { method: "POST" });
        const data = await response.json();
        if (data.status === "success") {
            isRecording = false;
            updateUIState();
            stopPolling();
            loadSteps();
            showToast("記録を停止しました。", "info");
        } else {
            showToast(data.message, "danger");
        }
    } catch (e) {
        showToast("エラーが発生しました", "danger");
    }
}

// API Call: Clear Steps
async function clearSteps() {
    if (!confirm("本当にすべての記録を削除しますか？")) return;
    try {
        const response = await fetch("/api/clear", { method: "POST" });
        const data = await response.json();
        if (data.status === "success") {
            steps = [];
            renderSteps();
            showToast("すべての記録をクリアしました。", "info");
        }
    } catch (e) {
        showToast("エラーが発生しました", "danger");
    }
}

// API Call: Load Steps
async function loadSteps() {
    try {
        const response = await fetch("/api/steps");
        const data = await response.json();
        
        const newSteps = data.steps || [];
        const hasDeletedSteps = data.has_deleted_steps || false;

        if (btnUndo) {
            btnUndo.disabled = !hasDeletedSteps;
        }

        // Check if length or content has changed to avoid unnecessary re-rendering
        if (JSON.stringify(newSteps) !== JSON.stringify(steps)) {
            steps = newSteps;
            renderSteps();
        }
    } catch (e) {
        console.error("Failed to load steps", e);
    }
}

// Render steps list
function renderSteps() {
    stepCountBadge.textContent = steps.length;

    if (steps.length === 0) {
        placeholder.style.display = "block";
        stepsList.innerHTML = "";
        return;
    }

    placeholder.style.display = "none";
    
    // Build list
    stepsList.innerHTML = steps.map(step => {
        const cacheBuster = Date.now();
        const autoBlurBadge = step.auto_blurred ? '<span class="auto-blur-label">自動モザイク適用済</span>' : '';
        const blurResetBtn = step.is_blurred 
            ? `<button class="btn btn-secondary" onclick="resetStepBlur(${step.id})">🔄 モザイク解除</button>` 
            : '';
        return `
            <div class="step-card" id="step-card-${step.id}">
                <div class="step-card-header">
                    <span class="step-num">手順 ${step.id}</span>
                    <div class="step-meta">
                        <span class="step-window-badge" title="${escapeHtml(step.window_title)}">${escapeHtml(step.window_title)}</span>
                        <span class="step-time">${step.timestamp}</span>
                    </div>
                </div>
                <div class="step-card-body">
                    <div class="step-info-col">
                        <div class="step-desc-group">
                            <label>操作説明文:</label>
                            <textarea 
                                class="step-desc-input" 
                                rows="3" 
                                onblur="updateStepDescription(${step.id}, this.value)"
                            >${escapeHtml(step.action_desc)}</textarea>
                        </div>
                        <div class="step-actions">
                            <button class="btn btn-warning" onclick="openBlurModal(${step.id}, '${step.image_name}')">
                                ✂ モザイクを追加
                            </button>
                            ${blurResetBtn}
                            <button class="btn btn-secondary" onclick="deleteStep(${step.id})">
                                🗑 削除
                            </button>
                        </div>
                    </div>
                    <div class="step-image-col">
                        <div class="image-preview-wrapper">
                            ${autoBlurBadge}
                            <img id="img-preview-${step.id}" src="/temp_images/${step.image_name}?t=${cacheBuster}" alt="Step ${step.id}" onclick="openZoomModal(this.src)">
                        </div>
                    </div>
                </div>
            </div>
        `;
    }).join("");
}

// API Call: Update Description on blur
async function updateStepDescription(id, value) {
    try {
        const response = await fetch("/api/steps/edit", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ id, action_desc: value })
        });
        const data = await response.json();
        if (data.status !== "success") {
            showToast("説明文の保存に失敗しました", "danger");
        }
    } catch (e) {
        showToast("通信エラーが発生しました", "danger");
    }
}

// API Call: Delete single step
async function deleteStep(id) {
    if (!confirm(`手順 ${id} を削除しますか？`)) return;
    try {
        const response = await fetch("/api/steps/delete", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ id })
        });
        const data = await response.json();
        if (data.status === "success") {
            loadSteps();
            showToast(`手順を削除しました。`, "info");
        }
    } catch (e) {
        showToast("エラーが発生しました", "danger");
    }
}

// API Call: Undo last deleted step
async function undoDeleteStep() {
    try {
        const response = await fetch("/api/steps/undo_delete", {
            method: "POST"
        });
        const data = await response.json();
        if (data.status === "success") {
            loadSteps();
            showToast("削除した手順を復元しました。", "success");
        } else {
            showToast(`復元エラー: ${data.message}`, "danger");
        }
    } catch (e) {
        showToast("エラーが発生しました", "danger");
    }
}

// API Call: Reset/remove all blurs for a single step
async function resetStepBlur(id) {
    if (!confirm(`手順 ${id} のモザイク（ぼかし）をすべて解除して、元画像に戻しますか？`)) return;
    try {
        const response = await fetch("/api/steps/reset_blur", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ id })
        });
        const data = await response.json();
        if (data.status === "success") {
            loadSteps();
            showToast(`モザイクを解除しました。`, "success");
        } else {
            showToast(`モザイク解除エラー: ${data.message}`, "danger");
        }
    } catch (e) {
        showToast("エラーが発生しました", "danger");
    }
}


// API Call: Export to Markdown and HTML
async function exportMarkdown() {
    const exportDir = exportDirInput.value.trim();
    const author = document.getElementById("manual-author").value.trim();
    const version = document.getElementById("manual-version").value.trim() || "1.0.0";
    const specs = document.getElementById("manual-specs").value.trim();
    
    showToast("手順書ファイルを作成中...", "info");
    
    try {
        const response = await fetch("/api/export", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ 
                export_dir: exportDir,
                author: author,
                version: version,
                system_specs: specs
            })
        });
        const data = await response.json();
        if (data.status === "success") {
            showToast("エクスポートが完了し、フォルダを開きました！", "success");
        } else {
            showToast(`出力エラー: ${data.message}`, "danger");
        }
    } catch (e) {
        showToast("通信エラーが発生しました", "danger");
    }
}

// API Call: Shutdown Server
async function shutdownServer() {
    if (!confirm("ステップ記録ツールを終了しますか？\n(記録中の未保存の手順データは消去されます)")) return;
    
    stopPolling();
    showToast("サーバーをシャットダウンしています...", "info");
    
    try {
        const response = await fetch("/api/shutdown", { method: "POST" });
        const data = await response.json();
        
        if (data.status === "success") {
            showShutdownPage();
        } else {
            showToast(`終了エラー: ${data.message}`, "danger");
        }
    } catch (e) {
        // Fetch failing is expected because the server terminates immediately
        showShutdownPage();
    }
}

function showShutdownPage() {
    document.body.innerHTML = `
        <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 80vh; text-align: center; font-family: sans-serif; color: #f8fafc; padding: 2rem;">
            <div style="font-size: 4rem; margin-bottom: 1.5rem;">👋</div>
            <h2 style="font-size: 1.8rem; font-weight: 700; margin-bottom: 1rem; color: #38bdf8;">ステップ記録ツールを終了しました</h2>
            <p style="font-size: 1.1rem; color: #94a3b8; margin-bottom: 0.5rem; max-width: 500px; line-height: 1.6;">
                サーバーは正常に停止しました。
            </p>
            <p style="font-size: 1rem; color: #64748b; margin-bottom: 2rem;">
                このブラウザのタブを閉じてください。ターミナル（黒い画面）も自動的に終了します。
            </p>
            <button onclick="window.close()" class="btn btn-secondary" style="padding: 0.75rem 1.5rem; font-size: 1rem; border-radius: 8px; background-color: rgba(255, 255, 255, 0.1); border: none; color: #f8fafc; cursor: pointer; font-weight: 600;">このタブを閉じる</button>
        </div>
    `;
}

// Open Manual Blur Modal
function openBlurModal(stepId, imageName) {
    activeStepId = stepId;
    isDrawing = false;
    applyBlurBtn.disabled = true;

    // Load source image
    modalImg.src = `/temp_images/${imageName}?t=${Date.now()}`;
    modalImg.onload = () => {
        // Set canvas dimensions based on screen limits
        const maxWidth = Math.min(800, window.innerWidth * 0.8);
        const maxHeight = window.innerHeight * 0.6;
        
        let width = modalImg.naturalWidth;
        let height = modalImg.naturalHeight;
        
        // Scale down to fit preview constraints
        if (width > maxWidth) {
            height = (maxWidth / width) * height;
            width = maxWidth;
        }
        if (height > maxHeight) {
            width = (maxHeight / height) * width;
            height = maxHeight;
        }
        
        canvas.width = width;
        canvas.height = height;
        
        // Render initial image to canvas
        ctx.drawImage(modalImg, 0, 0, width, height);
        
        // Show modal
        document.getElementById("blur-modal").classList.add("active");
    };
}

function closeModal() {
    document.getElementById("blur-modal").classList.remove("active");
    activeStepId = null;
    isDrawing = false;
}

// Canvas Drawing Event Handlers
function startDrawing(e) {
    isDrawing = true;
    const rect = canvas.getBoundingClientRect();
    startX = e.clientX - rect.left;
    startY = e.clientY - rect.top;
    endX = startX;
    endY = startY;
}

function drawSelection(e) {
    if (!isDrawing) return;
    const rect = canvas.getBoundingClientRect();
    endX = e.clientX - rect.left;
    endY = e.clientY - rect.top;

    // Redraw image first
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(modalImg, 0, 0, canvas.width, canvas.height);

    // Draw select box overlay
    ctx.fillStyle = "rgba(239, 68, 68, 0.25)"; // Transparent red overlay
    ctx.strokeStyle = "#ef4444"; // Solid red border
    ctx.lineWidth = 2;
    
    const w = endX - startX;
    const h = endY - startY;
    
    ctx.fillRect(startX, startY, w, h);
    ctx.strokeRect(startX, startY, w, h);
}

function stopDrawing() {
    if (!isDrawing) return;
    isDrawing = false;
    
    // Enable the apply button if a valid area was dragged
    const w = Math.abs(endX - startX);
    const h = Math.abs(endY - startY);
    if (w > 5 && h > 5) {
        applyBlurBtn.disabled = false;
    }
}

// API Call: Apply Manual Blur
async function applyManualBlur() {
    if (activeStepId === null) return;

    // Calculate scale ratio between canvas display size and actual image size
    const scaleX = modalImg.naturalWidth / canvas.width;
    const scaleY = modalImg.naturalHeight / canvas.height;

    // Build bounding rectangle
    const rect = [
        startX * scaleX,
        startY * scaleY,
        endX * scaleX,
        endY * scaleY
    ];

    try {
        const response = await fetch("/api/steps/blur", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ id: activeStepId, rect })
        });
        const data = await response.json();
        
        if (data.status === "success") {
            closeModal();
            // Reload steps to refresh preview image with cache buster
            loadSteps();
            showToast("モザイクを適用しました。", "success");
        } else {
            showToast(`モザイク適用エラー: ${data.message}`, "danger");
        }
    } catch (e) {
        showToast("エラーが発生しました", "danger");
    }
}

// Helper: Escape HTML to avoid XSS issues
function escapeHtml(str) {
    if (!str) return "";
    return str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

// Image Zoom State variables
let currentZoom = 1.0;
const zoomModal = document.getElementById("zoom-modal");
const zoomImg = document.getElementById("zoom-expanded-img");

// Open Image Zoom modal
function openZoomModal(src) {
    currentZoom = 1.0;
    zoomImg.src = src;
    zoomImg.style.transform = `scale(${currentZoom})`;
    zoomModal.classList.add("active");
    
    // Bind click listeners once
    document.getElementById("btn-zoom-in").onclick = () => adjustZoom(0.2);
    document.getElementById("btn-zoom-out").onclick = () => adjustZoom(-0.2);
    document.getElementById("btn-zoom-reset").onclick = () => adjustZoom(0, true);
}

function closeZoomModal() {
    zoomModal.classList.remove("active");
}

function adjustZoom(amount, reset = false) {
    if (reset) {
        currentZoom = 1.0;
    } else {
        currentZoom = Math.max(0.2, Math.min(4.0, currentZoom + amount));
    }
    zoomImg.style.transform = `scale(${currentZoom})`;
}

// GUI Folder Picker dialog via Python backend
async function selectFolderDialog() {
    try {
        const response = await fetch("/api/select_folder", { method: "POST" });
        const data = await response.json();
        if (data.status === "success") {
            exportDirInput.value = data.folder;
            showToast("出力フォルダを選択しました", "success");
        } else if (data.status === "error") {
            showToast(`フォルダ選択エラー: ${data.message}`, "danger");
        }
    } catch (e) {
        showToast("フォルダ選択中にエラーが発生しました", "danger");
    }
}

// Help Modal controls
const helpModal = document.getElementById("help-modal");
function openHelpModal() {
    helpModal.classList.add("active");
}
function closeHelpModal() {
    helpModal.classList.remove("active");
}

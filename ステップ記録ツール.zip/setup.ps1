# AI不使用・完全ローカル版ステップ記録ツール 起動スクリプト
# Windows PowerShell用

Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "  ステップ記録ツール (完全ローカル版) セットアップ  " -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan

# 1. Python of 存在確認
if (-not (Get-Command "python" -ErrorAction SilentlyContinue)) {
    Write-Host "[エラー] Pythonがシステムにインストールされていないか、PATHが通っていません。" -ForegroundColor Red
    Write-Host "Python (3.8以上) をインストールしてから再度お試しください。" -ForegroundColor Yellow
    Pause
    Exit
}

$pythonVersion = & python --version
Write-Host "使用するPython: $pythonVersion" -ForegroundColor Green

# 2. 仮想環境(.venv) の作成
if (-not (Test-Path ".venv")) {
    Write-Host "仮想環境(.venv) を作成しています.." -ForegroundColor Yellow
    & python -m venv .venv
    if (-not $?) {
        Write-Host "[エラー] 仮想環境の作成に失敗しました。" -ForegroundColor Red
        Pause
        Exit
    }
    Write-Host "仮想環境を作成しました。" -ForegroundColor Green
} else {
    Write-Host "既存の仮想環境(.venv) を使用します。" -ForegroundColor Green
}

# 3. 仮想環境の有効化とパッケージのインストール
Write-Host "依存ライブラリをインストールしています.." -ForegroundColor Yellow

$localFolder = "pip_packages"
$sharedFolder = "\\Jp-nml-fs-a01\A70\TENKAI\Libs"
$proxyUrl = "http://10.11.238.3:8080"
$installSuccess = $false

# 3.1 ローカルのオフラインフォルダからインストールを試みる
if (Test-Path $localFolder) {
    Write-Host "ローカルフォルダ ($localFolder) からインストールしています.." -ForegroundColor Green
    & .\.venv\Scripts\pip.exe install --no-index --find-links=$localFolder uiautomation pillow pynput pywin32 reportlab charset-normalizer
    $installSuccess = $?
}

# 3.2 共有ファイルサーバーからインストールを試みる
if (-not $installSuccess -and (Test-Path $sharedFolder)) {
    Write-Host "ファイルサーバー ($sharedFolder) からインストールしています.." -ForegroundColor Green
    & .\.venv\Scripts\pip.exe install --no-index --find-links=$sharedFolder uiautomation pillow pynput pywin32 reportlab charset-normalizer
    $installSuccess = $?
}

# 3.3 プロキシ経由でインターネットからインストールを試みる
if (-not $installSuccess) {
    Write-Host "プロキシ経由 ($proxyUrl) でインターネットからインストールしています.." -ForegroundColor Yellow
    & .\.venv\Scripts\pip.exe install --proxy $proxyUrl uiautomation pillow pynput pywin32 reportlab charset-normalizer
    $installSuccess = $?
}

# 3.4 直接インターネットからインストールを試みる (フォールバック)
if (-not $installSuccess) {
    Write-Host "直接インターネットからインストールしています.." -ForegroundColor Yellow
    & .\.venv\Scripts\pip.exe install uiautomation pillow pynput pywin32 reportlab charset-normalizer
    $installSuccess = $?
}

if (-not $installSuccess) {
    Write-Host "[エラー] すべてのインストール方法に失敗しました。" -ForegroundColor Red
    Write-Host "1. 社内ネットワーク（VPN）に接続し、ファイルサーバー ($sharedFolder) にアクセスできるか確認してください。" -ForegroundColor Yellow
    Write-Host "2. 外部通信制限がある場合は、社内プロキシの設定を確認してください。" -ForegroundColor Yellow
    Write-Host ""
    Pause
    Exit
}
Write-Host "ライブラリのインストールが完了しました。" -ForegroundColor Green

# 4. アプリケーションの起動
Write-Host "---------------------------------------------" -ForegroundColor Cyan
Write-Host "アプリケーションを起動しています.." -ForegroundColor Green
Write-Host "起動すると自動的にブラウザが開きます。" -ForegroundColor Green
Write-Host "サーバーを停止するには、このウィンドウで Ctrl+C を押してください。" -ForegroundColor Yellow
Write-Host "---------------------------------------------" -ForegroundColor Cyan

& .\.venv\Scripts\python.exe app.py

Write-Host "サーバーが停止しました。" -ForegroundColor Green
Pause

﻿# AI不使用・完全ローカル版ステップ記録ツール 起動スクリプト
# Windows PowerShell用

Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "  ステップ記録ツール (完全ローカル版) セットアップ  " -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan

# 1. Python of 存在確認
if (-not (Get-Command "python" -ErrorAction SilentlyContinue)) {
    Write-Host "[エラー] Pythonがシステムにインストールされていないか、PATHが通っていません。" -ForegroundColor Red
    Write-Host "Python (3.8以上) をインストールしてから再度お試しください。" -ForegroundColor Yellow
    Pause
    Exit
}

$pythonVersion = & python --version
Write-Host "使用するPython: $pythonVersion" -ForegroundColor Green

# 2. 仮想環境(.venv) の作成
if (-not (Test-Path ".venv")) {
    Write-Host "仮想環境(.venv) を作成しています.." -ForegroundColor Yellow
    & python -m venv .venv
    if (-not $?) {
        Write-Host "[エラー] 仮想環境の作成に失敗しました。" -ForegroundColor Red
        Pause
        Exit
    }
    Write-Host "仮想環境を作成しました。" -ForegroundColor Green
} else {
    Write-Host "既存の仮想環境(.venv) を使用します。" -ForegroundColor Green
}

# 3. 仮想環境の有効化とパッケージのインストール
Write-Host "依存ライブラリをインストールしています.." -ForegroundColor Yellow

$offlineFolder = "pip_packages"
$installSuccess = $false

if (Test-Path $offlineFolder) {
    Write-Host "オフラインフォルダ ($offlineFolder) からライブラリをインストールします.." -ForegroundColor Green
    & .\.venv\Scripts\pip.exe install --no-index --find-links=$offlineFolder uiautomation pillow pynput pywin32 reportlab charset-normalizer
    $installSuccess = $?
} else {
    Write-Host "インターネット経由でライブラリをインストールします.." -ForegroundColor Yellow
    # pipのアップグレードを試みる（失敗しても継続）
    & .\.venv\Scripts\python.exe -m pip install --upgrade pip > $null
    
    # パッケージのインストール
    & .\.venv\Scripts\pip.exe install uiautomation pillow pynput pywin32 reportlab charset-normalizer
    $installSuccess = $?
}

if (-not $installSuccess) {
    Write-Host "[エラー] ライブラリのインストールに失敗しました。" -ForegroundColor Red
    Write-Host "社内のネットワーク制限（プロキシ等）でブロックされた可能性があります。" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "■ 対処法1: プロキシをコマンドで指定してインストールする場合" -ForegroundColor Cyan
    Write-Host "以下のコマンドを実行して、プロキシを手動で指定してパッケージを導入してください。" -ForegroundColor Yellow
    Write-Host "  .\.venv\Scripts\pip.exe install --proxy http://[プロキシサーバー]:[ポート番号] uiautomation pillow pynput pywin32 reportlab charset-normalizer" -ForegroundColor White
    Write-Host ""
    Write-Host "■ 対処法2: 完全オフラインでインストールする場合" -ForegroundColor Cyan
    Write-Host "インターネットの繋がるPCで「オフライン用パッケージ取得.bat」を実行し、" -ForegroundColor Yellow
    Write-Host "作成された「pip_packages」フォルダをこのPCのフォルダ内にコピーしてから再度実行してください。" -ForegroundColor Yellow
    Pause
    Exit
}
Write-Host "ライブラリのインストールが完了しました。" -ForegroundColor Green

# 4. アプリケーションの起動
Write-Host "---------------------------------------------" -ForegroundColor Cyan
Write-Host "アプリケーションを起動しています.." -ForegroundColor Green
Write-Host "起動すると自動的にブラウザが開きます。" -ForegroundColor Green
Write-Host "サーバーを停止するには、このウィンドウで Ctrl+C を押してください。" -ForegroundColor Yellow
Write-Host "---------------------------------------------" -ForegroundColor Cyan

& .\.venv\Scripts\python.exe app.py

Write-Host "サーバーが停止しました。" -ForegroundColor Green
Pause

import os
import time
import threading
import ctypes
from datetime import datetime
from PIL import ImageGrab, ImageFilter, ImageDraw
import pynput
import win32gui
import uiautomation as auto

# DPI awareness settings for Windows to ensure coordinate consistency
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2) # PROCESS_PER_MONITOR_DPI_AWARE
except Exception:
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass

class StepsListener:
    def __init__(self, temp_dir, on_step_captured=None):
        self.temp_dir = temp_dir
        self.on_step_captured = on_step_captured
        self.steps = []
        self.deleted_steps = []
        self.is_recording = False
        self.mouse_listener = None
        self.keyboard_listener = None
        self._lock = threading.Lock()
        self.step_counter = 0
        self.disable_uia = False
        self.enable_keyboard_hook = False

        # Ensure temp directory exists
        os.makedirs(self.temp_dir, exist_ok=True)

    def start(self):
        with self._lock:
            if self.is_recording:
                return
            self.is_recording = True
            
            # Start mouse listener
            self.mouse_listener = pynput.mouse.Listener(on_click=self._on_click)
            self.mouse_listener.start()
            
            # Start keyboard listener if requested (opt-in)
            if self.enable_keyboard_hook:
                self.keyboard_listener = pynput.keyboard.Listener(on_press=self._on_key_press)
                self.keyboard_listener.start()
                print("StepsListener keyboard hook started.")
                
            print("StepsListener started.")

    def stop(self):
        with self._lock:
            if not self.is_recording:
                return
            self.is_recording = False
            
            # Stop mouse listener
            if self.mouse_listener:
                self.mouse_listener.stop()
                self.mouse_listener = None
                
            # Stop keyboard listener
            if self.keyboard_listener:
                self.keyboard_listener.stop()
                self.keyboard_listener = None
                
            print("StepsListener stopped.")

    def clear(self):
        with self._lock:
            self.steps = []
            self.deleted_steps = []
            self.step_counter = 0
            # Clean temp directory
            if os.path.exists(self.temp_dir):
                for f in os.listdir(self.temp_dir):
                    if f.endswith('.png'):
                        try:
                            os.remove(os.path.join(self.temp_dir, f))
                        except Exception:
                            pass

    def _get_active_window_title(self):
        hwnd = win32gui.GetForegroundWindow()
        if hwnd:
            return win32gui.GetWindowText(hwnd)
        return "Unknown Window"

    def _on_click(self, x, y, button, pressed):
        if not pressed:
            return

        if button != pynput.mouse.Button.left:
            return

        # Acquire a lock or check recording status
        if not self.is_recording:
            return

        # Start a thread to handle capture so we don't block the mouse event thread
        threading.Thread(target=self._capture_step, args=(x, y)).start()

    def _capture_step(self, x, y):
        # Wait briefly for UI to register the click and update/redraw
        time.sleep(0.15)

        # Get active window info
        window_title = self._get_active_window_title()

        # Ignore clicks inside our own application interface
        # We assume the browser window hosting our UI will contain "ステップ記録ツール"
        if "ステップ記録ツール" in window_title:
            return

        # Capture the screen
        try:
            screenshot = ImageGrab.grab()
        except Exception as e:
            print(f"Failed to capture screenshot: {e}")
            return

        # Inspect the UI element at the clicked position
        control_name = ""
        control_type = "Unknown"
        action_desc = ""
        rect_to_blur = None

        if not self.disable_uia:
            try:
                # ControlFromPoint takes (x, y) coordinates
                control = auto.ControlFromPoint(x, y)
                if control:
                    control_name = control.Name or ""
                    control_type = control.ControlTypeName or "Control"
                    
                    # Check for sensitive controls that should be auto-blurred
                    # Typically, edit controls, password fields, or values containing input
                    is_input = control_type in ["EditControl", "PasswordControl"]
                    
                    # Get the element bounding rectangle and apply auto-blur if appropriate
                    if is_input:
                        uia_rect = control.BoundingRectangle
                        if uia_rect:
                            # BoundingRectangle properties: left, top, right, bottom
                            # Ensure coordinates are within screen boundaries
                            screen_w, screen_h = screenshot.size
                            l = max(0, min(uia_rect.left, screen_w))
                            t = max(0, min(uia_rect.top, screen_h))
                            r = max(0, min(uia_rect.right, screen_w))
                            b = max(0, min(uia_rect.bottom, screen_h))
                            
                            if l < r and t < b:
                                w_rect = r - l
                                h_rect = b - t
                                area_rect = w_rect * h_rect
                                
                                # Skip auto-blur if the area is too large (e.g. huge text areas or container panels)
                                is_too_large = (
                                    w_rect > screen_w * 0.40 or
                                    h_rect > screen_h * 0.20 or
                                    area_rect > screen_w * screen_h * 0.08
                                )
                                if not is_too_large:
                                    rect_to_blur = (l, t, r, b)

                    # Formulate the natural description in Japanese
                    if is_input:
                        if control_name:
                            action_desc = f"[入力欄]「{control_name}」を選択します"
                        else:
                            action_desc = "[入力欄] を選択します"
                    elif control_type == "ButtonControl":
                        action_desc = f"[ボタン]「{control_name}」をクリックします"
                    elif control_type == "MenuItemControl":
                        action_desc = f"[メニュー]「{control_name}」を選択します"
                    elif control_type == "TabItemControl":
                        action_desc = f"[タブ]「{control_name}」を選択します"
                    elif control_type == "CheckBoxControl":
                        action_desc = f"[チェックボックス]「{control_name}」の状態を変更します"
                    elif control_name:
                        action_desc = f"[{control_type.replace('Control', '')}]「{control_name}」をクリックします"
                    else:
                        action_desc = f"[{control_type.replace('Control', '')}] をクリックします"
                else:
                    action_desc = "画面をクリックします"
            except Exception as e:
                print(f"Error reading UI element: {e}")
                action_desc = "画面をクリックします"
        else:
            action_desc = "画面をクリックします"

        # Draw a red pointer (circle) on the screenshot showing exactly where the user clicked
        try:
            draw = ImageDraw.Draw(screenshot)
            radius = 12
            draw.ellipse((x - radius, y - radius, x + radius, y + radius), outline="red", width=3)
            # Add a small dot in the center
            draw.ellipse((x - 2, y - 2, x + 2, y + 2), fill="red")
        except Exception as e:
            print(f"Failed to draw click pointer: {e}")

        # Save the original image (with pointer, without blur) first
        self.step_counter += 1
        timestamp_suffix = int(time.time())
        orig_img_name = f"step_{self.step_counter}_{timestamp_suffix}_orig.png"
        orig_img_path = os.path.join(self.temp_dir, orig_img_name)
        try:
            screenshot.save(orig_img_path, "PNG")
        except Exception as e:
            print(f"Failed to save original screenshot file: {e}")

        # Apply auto-blur (auto-masking) if it's an input field
        if rect_to_blur:
            try:
                # Crop, blur, and paste back
                cropped = screenshot.crop(rect_to_blur)
                # Apply heavy Gaussian Blur to make text unreadable
                blurred = cropped.filter(ImageFilter.GaussianBlur(radius=15))
                screenshot.paste(blurred, rect_to_blur)
                
                # Optional: draw a subtle border around the auto-blurred area
                draw = ImageDraw.Draw(screenshot)
                draw.rectangle(rect_to_blur, outline="orange", width=2)
            except Exception as e:
                print(f"Auto-blur failed: {e}")

        # Save processed screenshot
        img_name = f"step_{self.step_counter}_{timestamp_suffix}.png"
        img_path = os.path.join(self.temp_dir, img_name)
        try:
            screenshot.save(img_path, "PNG")
        except Exception as e:
            print(f"Failed to save screenshot file: {e}")
            return

        # Create step object
        step = {
            "id": self.step_counter,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "window_title": window_title,
            "action_desc": action_desc,
            "image_name": img_name,
            "original_image_name": orig_img_name,
            "x": x,
            "y": y,
            "control_type": control_type,
            "control_name": control_name,
            "auto_blurred": True if rect_to_blur else False,
            "is_blurred": True if rect_to_blur else False
        }

        with self._lock:
            self.steps.append(step)

        if self.on_step_captured:
            self.on_step_captured(step)

    def _on_key_press(self, key):
        if not self.is_recording:
            return
        
        # Monitor only Enter and Tab keys to prevent performance issues and screenshot floods
        if key in [pynput.keyboard.Key.enter, pynput.keyboard.Key.tab]:
            # Start thread to process capture asynchronously to avoid freezing the OS hook thread
            threading.Thread(target=self._capture_keyboard_step, args=(key,)).start()

    def _capture_keyboard_step(self, key):
        # Wait briefly for UI layout to settle after key stroke
        time.sleep(0.2)

        # Get active window info
        window_title = self._get_active_window_title()

        # Ignore actions in our own app
        if "ステップ記録ツール" in window_title:
            return

        # Capture the screen
        try:
            screenshot = ImageGrab.grab()
        except Exception as e:
            print(f"Failed to capture screen on keyboard event: {e}")
            return

        # Assign description based on key
        key_name = "Enter" if key == pynput.keyboard.Key.enter else "Tab"
        if key == pynput.keyboard.Key.enter:
            action_desc = f"[確定] Enterキーを押します"
        else:
            action_desc = f"[移動] Tabキーを押します"

        # Increment step and define names
        self.step_counter += 1
        timestamp_suffix = int(time.time())
        img_name = f"step_{self.step_counter}_{timestamp_suffix}.png"
        orig_img_name = f"step_{self.step_counter}_{timestamp_suffix}_orig.png"

        # Save both processed and original screenshots (they are identical because no blur is applied)
        try:
            img_path = os.path.join(self.temp_dir, img_name)
            orig_img_path = os.path.join(self.temp_dir, orig_img_name)
            screenshot.save(orig_img_path, "PNG")
            screenshot.save(img_path, "PNG")
        except Exception as e:
            print(f"Failed to save keyboard step screenshots: {e}")
            return

        # Construct step object
        step = {
            "id": self.step_counter,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "window_title": window_title,
            "action_desc": action_desc,
            "image_name": img_name,
            "original_image_name": orig_img_name,
            "x": None,
            "y": None,
            "control_type": "Keyboard",
            "control_name": key_name,
            "auto_blurred": False,
            "is_blurred": False
        }

        with self._lock:
            self.steps.append(step)

        if self.on_step_captured:
            self.on_step_captured(step)


